import { useEffect, useRef } from "react";
import { flowSteps } from "../../data/mockData";
import { buildDoctorHandoff, getUrgencyClass } from "../../utils/profile";

function formatDistance(distanceKm) {
  if (typeof distanceKm === "number" && Number.isFinite(distanceKm)) {
    return `${distanceKm.toFixed(1)} km`;
  }

  return distanceKm ? `${distanceKm} km` : "Distance unavailable";
}

function formatCoordinates(coords) {
  if (!coords || typeof coords.lat !== "number" || typeof coords.lng !== "number") {
    return "";
  }

  return `${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}`;
}

export function TriageView({
  profile,
  profileAvatar,
  language,
  location,
  preview,
  photoName,
  messages,
  message,
  error,
  loading,
  result,
  nearbyHospitals,
  locationContext,
  aiConfigured,
  voiceSupported,
  voiceListening,
  voiceError,
  onLanguageChange,
  onLocationChange,
  onMessageChange,
  onPromptSelect,
  onImageSelect,
  onClearImage,
  onAnalyze,
  onUseGps,
  onGoProfile,
  onDownloadReport,
  onDownloadHandoff,
  onToggleVoiceInput,
  quickPrompts,
  gpsLinked
}) {
  const urgencyClass = getUrgencyClass(result?.urgency?.level);
  const analysisMode = aiConfigured ? "AI assisted" : "Instant text triage";
  const streamRef = useRef(null);
  const cameraInputRef = useRef(null);
  const locationDetails = [
    formatCoordinates(locationContext?.coordinates),
    locationContext?.accuracyMeters ? `Accuracy ~${locationContext.accuracyMeters}m` : "",
    locationContext?.searchRadiusKm ? `${locationContext.searchRadiusKm} km search radius` : ""
  ].filter(Boolean);
  const locationSummary =
    locationContext?.label || (gpsLinked ? "Current GPS linked" : location || "Add a city or use GPS");
  const locationSource =
    locationContext?.dataSource ||
    (nearbyHospitals[0]?.source ? nearbyHospitals[0].source : "Location-aware care suggestions");
  const doctorHandoff = result ? buildDoctorHandoff(result, profile) : null;

  useEffect(() => {
    if (!streamRef.current) {
      return;
    }

    streamRef.current.scrollTop = streamRef.current.scrollHeight;
  }, [messages, loading]);

  return (
    <section className="workspace workspace--triage">
      <div className="workspace__main workspace__main--triage">
        <div className="panel-heading panel-heading--tight">
          <div>
            <p className="eyebrow">Symptom Workspace</p>
            <h3>Capture symptoms, photo context, and exact location</h3>
          </div>
          <div className="field field--compact">
            <label htmlFor="language">Language</label>
            <select id="language" value={language} onChange={(event) => onLanguageChange(event.target.value)}>
              <option>English</option>
              <option>Hindi</option>
              <option>Bengali</option>
            </select>
          </div>
        </div>

        <div className="triage-profile-banner triage-profile-banner--compact">
          <img src={profileAvatar} alt={`${profile.displayName} avatar`} />
          <div>
            <strong>{profile.displayName}</strong>
            <p>
              Age {profile.age || "--"} / Height {profile.heightCm || "--"} cm / Weight {profile.weightKg || "--"} kg
            </p>
          </div>
          <button type="button" className="button button--ghost" onClick={onGoProfile}>
            Edit
          </button>
        </div>

        <div className="triage-main-grid">
          <div className="composer composer--dense">
            <div className="subsection-heading subsection-heading--compact">
              <div>
                <h4>Symptoms</h4>
                <p>Describe what is happening, how long it has lasted, and whether it is worsening.</p>
              </div>
              {voiceSupported ? (
                <button
                  type="button"
                  className={`button button--ghost button--small ${voiceListening ? "button--live" : ""}`}
                  onClick={onToggleVoiceInput}
                >
                  {voiceListening ? "Stop Voice" : "Voice Input"}
                </button>
              ) : null}
            </div>
            <label className="field field--full">
              <span>Symptom summary</span>
              <textarea
                value={message}
                onChange={(event) => onMessageChange(event.target.value)}
                placeholder="Example: I have fever, cough, and fatigue for 2 days. My throat looks red."
                rows={5}
              />
            </label>

            <div className="triage-support-grid">
              <label className="upload-tile upload-tile--media">
                <input
                  className="upload-tile__input"
                  type="file"
                  accept="image/*"
                  onChange={onImageSelect}
                />
                <span>Symptom photo</span>
                <strong>{photoName || "Upload a symptom photo"}</strong>
                <p>
                  {photoName
                    ? "Tap here to replace the current image."
                    : "Choose an image from the phone gallery or local files."}
                </p>
              </label>

              <div className="upload-tile upload-tile--media mobile-only-upload">
                <input
                  ref={cameraInputRef}
                  className="upload-tile__input"
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={onImageSelect}
                />
                <span>Camera capture</span>
                <strong>Take a photo in app</strong>
                <p>Open the phone camera directly and send the captured image through the same AI flow.</p>
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() => cameraInputRef.current?.click()}
                >
                  Open Camera
                </button>
              </div>

              <div className="location-stack location-stack--card">
                <div className="subsection-heading subsection-heading--compact">
                  <div>
                    <h4>Location</h4>
                    <p>GPS gives the most accurate nearby hospitals and clinics.</p>
                  </div>
                  {gpsLinked ? <span className="subsection-count">GPS on</span> : null}
                </div>
                <label className="field">
                  <span>City or area</span>
                  <input type="text" value={location} onChange={(event) => onLocationChange(event.target.value)} />
                </label>
                <div className="location-actions">
                  <button type="button" className="button button--ghost" onClick={onUseGps}>
                    {gpsLinked ? "Refresh Exact GPS" : "Use Exact GPS"}
                  </button>
                  <p className="inline-note">
                    {gpsLinked
                      ? "Exact coordinates will be used to rank hospitals and clinics by nearest distance."
                      : "Turn on location for the most precise nearby emergency results."}
                  </p>
                </div>
              </div>
            </div>

            {preview ? (
              <div className="preview-tile">
                <img src={preview} alt="Symptom preview" />
                <div>
                  <p>Attached photo</p>
                  <strong>{photoName || "Symptom image"}</strong>
                  <button type="button" className="link-button" onClick={onClearImage}>
                    Remove photo
                  </button>
                </div>
              </div>
            ) : null}

            {error ? <p className="error-text">{error}</p> : null}
            {voiceError ? <p className="status-note status-note--voice">{voiceError}</p> : null}
            {voiceListening ? (
              <p className="status-note" aria-live="polite">
                Listening for your symptom description...
              </p>
            ) : null}
            {loading ? (
              <p className="status-note" aria-live="polite">
                Preparing your triage result...
              </p>
            ) : null}

            <div className="composer__actions composer__actions--split">
              <button type="button" className="button" onClick={onAnalyze} disabled={loading}>
                {loading ? "Analyzing..." : "Analyze Symptoms"}
              </button>
              <p className="inline-note inline-note--support">
                PulsePath combines symptoms, optional image context, and live nearby-care matching.
              </p>
            </div>
          </div>

          <section className="conversation-panel">
            <div className="subsection-heading">
              <div>
                <h4>Conversation stream</h4>
                <p>Review the latest symptom summary before sending another update.</p>
              </div>
              <span className="subsection-count">{messages.length} updates</span>
            </div>

            <div className="message-stream message-stream--workspace" ref={streamRef}>
              {messages.map((entry, index) => (
                <article
                  key={`${entry.role}-${index}`}
                  className={`message-bubble message-bubble--${entry.role}`}
                >
                  <span className="message-bubble__role">
                    {entry.role === "assistant" ? "PulsePath" : "You"}
                  </span>
                  <p>{entry.content}</p>
                </article>
              ))}
            </div>
          </section>

          <section className="prompt-panel">
            <div className="subsection-heading subsection-heading--compact">
              <div>
                <h4>Quick prompts</h4>
                <p>Tap one to prefill the symptom box faster.</p>
              </div>
            </div>

            <div className="quick-prompts quick-prompts--grid quick-prompts--panel">
              {quickPrompts.map((prompt) => (
                <button key={prompt.label} type="button" onClick={() => onPromptSelect(prompt.prompt)}>
                  {prompt.label}: {prompt.description}
                </button>
              ))}
            </div>
          </section>
        </div>
      </div>

      <aside className="workspace__side workspace__side--triage" id="triage-result">
        <div className={`result-hero result-hero--compact ${urgencyClass}`}>
          <div className="result-hero__top">
            <div>
              <p className="eyebrow">Live Triage Result</p>
              <h3>{result?.urgency?.level || "Awaiting analysis"}</h3>
            </div>
            {result ? (
              <div className="button-row">
                <button type="button" className="button button--ghost button--small" onClick={onDownloadReport}>
                  Export PDF
                </button>
                <button type="button" className="button button--ghost button--small" onClick={onDownloadHandoff}>
                  Handoff PDF
                </button>
              </div>
            ) : null}
          </div>
          <p>
            {result?.urgency?.advice ||
              "Once symptoms are submitted, this area will show urgency, doctor type, and next actions."}
          </p>
          <div className="result-hero__chips">
            <span className="signal-pill">{analysisMode}</span>
            <span className="signal-pill signal-pill--soft">
              {result?.recommendedDoctor?.specialty || "Doctor recommendation pending"}
            </span>
          </div>
        </div>

        <div className="result-panel result-panel--triage">
          <section className="location-card">
            <div>
              <p className="eyebrow">Location Match</p>
              <h4>{locationSummary}</h4>
              <p>
                {locationContext?.displayName ||
                  "Use GPS or a city/area name to search nearby hospitals and clinics."}
              </p>
            </div>
            <div className="location-card__meta">
              {locationDetails.map((detail) => (
                <span key={detail}>{detail}</span>
              ))}
              <span>{locationSource}</span>
            </div>
            {locationContext?.mapUrl ? (
              <a href={locationContext.mapUrl} target="_blank" rel="noreferrer">
                Open current location
              </a>
            ) : null}
          </section>

          <p className="summary-copy">
            {result?.summary ||
              "PulsePath combines symptom text, optional image context, and caution-first routing logic."}
          </p>

          <div className="result-grid result-grid--triage">
            <section>
              <h4>Possible conditions</h4>
              <ul className="stack-list">
                {(result?.possibleConditions || flowSteps.map((step) => ({ name: step, probability: "" }))).map(
                  (item) => (
                    <li key={item.name}>
                      <strong>{item.name}</strong>
                      {item.probability ? <span>{item.probability}</span> : null}
                      {item.reason ? <p>{item.reason}</p> : null}
                    </li>
                  )
                )}
              </ul>
            </section>

            <section>
              <h4>Detected symptoms</h4>
              <ul className="tag-list">
                {(result?.symptoms || ["fever", "rash", "breathing issues", "stomach pain"]).map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </section>

            <section>
              <h4>Next steps</h4>
              <ul className="stack-list">
                {(result?.nextSteps || [
                  "Answer follow-up questions",
                  "Review urgency guidance",
                  "Open nearby care providers"
                ]).map((item) => (
                  <li key={item}>
                    <strong>{item}</strong>
                  </li>
                ))}
              </ul>
            </section>

            <section>
              <h4>Medicine and allergy safety</h4>
              <ul className="stack-list stack-list--safety">
                {(result?.safetyChecks || []).length ? (
                  result.safetyChecks.map((item) => (
                    <li key={`${item.severity}-${item.title}`} className="safety-item">
                      <div className="hospital-list__topline">
                        <strong>{item.title}</strong>
                        <span className={`safety-pill safety-pill--${item.severity.toLowerCase()}`}>{item.severity}</span>
                      </div>
                      <p>{item.detail}</p>
                    </li>
                  ))
                ) : (
                  <li>
                    <strong>No extra medicine or allergy risks were flagged from the saved profile.</strong>
                  </li>
                )}
              </ul>
            </section>

            <section>
              <h4>Follow-up questions</h4>
              <ul className="stack-list">
                {(result?.followUpQuestions || [
                  "How long has the symptom been present?",
                  "Has it been getting worse?",
                  "Is there fever, pain, or swelling?"
                ]).map((item) => (
                  <li key={item}>
                    <strong>{item}</strong>
                  </li>
                ))}
              </ul>
            </section>
          </div>

          {doctorHandoff ? (
            <section className="handoff-card">
              <div className="subsection-heading subsection-heading--compact">
                <div>
                  <h4>Doctor handoff summary</h4>
                  <p>Show this summary to a clinician or export it for a quicker handoff.</p>
                </div>
              </div>

              <div className="handoff-card__grid">
                {doctorHandoff.lines.map((item) => (
                  <div key={item.label} className="handoff-card__line">
                    <span>{item.label}</span>
                    <strong>{item.value}</strong>
                  </div>
                ))}
              </div>
            </section>
          ) : null}

          {result?.imageObservations?.length ? (
            <section>
              <h4>Photo insight</h4>
              <ul className="stack-list">
                {result.imageObservations.map((item) => (
                  <li key={item}>
                    <strong>{item}</strong>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          <section className="care-panel">
            <h4>Nearby hospitals and clinics</h4>
            <ul className="hospital-list hospital-list--dense">
              {nearbyHospitals.length ? (
                nearbyHospitals.map((item) => (
                  <li key={item.id || `${item.name}-${item.distanceKm}`}>
                    <div className="hospital-list__body">
                      <div className="hospital-list__topline">
                        <strong>{item.name}</strong>
                        <span className="distance-pill">{formatDistance(item.distanceKm)}</span>
                      </div>
                      <p>{[item.type, item.address || item.area].filter(Boolean).join(" / ")}</p>
                      <div className="hospital-tags">
                        {item.emergencyReady ? <span>Emergency</span> : null}
                        {typeof item.suitabilityScore === "number" ? (
                          <span>{`${item.suitabilityLabel || "Match"} ${item.suitabilityScore}`}</span>
                        ) : null}
                        {(Array.isArray(item.specialties) ? item.specialties : []).slice(0, 3).map((tag) => (
                          <span key={`${item.name}-${tag}`}>{tag}</span>
                        ))}
                      </div>
                      {item.suitabilityReason ? <p>{item.suitabilityReason}</p> : null}
                    </div>
                    <div className="hospital-list__actions">
                      {formatCoordinates(item.coordinates) ? (
                        <span className="hospital-coords">{formatCoordinates(item.coordinates)}</span>
                      ) : null}
                      <a href={item.mapUrl} target="_blank" rel="noreferrer">
                        Open route
                      </a>
                    </div>
                  </li>
                ))
              ) : (
                <li>
                  <div>
                    <strong>Care options will appear after analysis</strong>
                    <p>Location-aware clinics and hospital suggestions are shown here.</p>
                  </div>
                </li>
              )}
            </ul>
          </section>

          <p className="disclaimer">
            {result?.disclaimer ||
              "This experience does not diagnose disease. Emergency symptoms should always be escalated to local medical services immediately."}
          </p>
          {!aiConfigured ? (
            <p className="disclaimer disclaimer--setup">
              Text symptoms are being analyzed instantly on-device, so the app still works even if the API is not running.
              Image-aware AI can be turned on later, but normal text triage is available right now.
            </p>
          ) : null}
        </div>
      </aside>
    </section>
  );
}
