import { SharedCard } from "../SharedCard";

export function HomeView({
  profile,
  profileAvatar,
  profileReady,
  aiConfigured,
  preview,
  result,
  latestHistory,
  quickPrompts,
  trustHighlights,
  onGoTriage,
  onGoProfile,
  onPromptSelect,
  onOpenLatest
}) {
  return (
    <>
      <section className="hero-panel hero-panel--home">
        <div className="hero-panel__copy">
          <p className="eyebrow">Photo-aware healthcare assistant</p>
          <h2>Describe symptoms, capture visible signs, and reach the right doctor faster.</h2>
          <p className="hero-text">
            Built for phone-first care access with multilingual chat, urgency alerts, and nearby
            care suggestions in one calm workflow for {profile.displayName}.
          </p>

          <div className="hero-actions">
            <button type="button" className="button" onClick={onGoTriage}>
              Start Smart Triage
            </button>
            <button type="button" className="button button--ghost" onClick={onGoProfile}>
              Edit Profile
            </button>
          </div>
        </div>

        <div className="hero-panel__visual">
          <div className="phone-surface">
            <div className="phone-surface__header">
              <div className="profile-mini">
                <img src={profileAvatar} alt={`${profile.displayName} avatar`} />
                <div>
                  <span>{profile.displayName}</span>
                  <strong>{profileReady ? "Personalization ready" : "Complete profile details"}</strong>
                </div>
              </div>
              <div>
                <span>AI mode</span>
                <strong>{aiConfigured ? "OpenRouter Live" : "Demo Mode"}</strong>
              </div>
            </div>

            <div className="phone-surface__card phone-surface__card--primary">
              <span className="pill">AI Decision Support</span>
              <strong>Urgency route in under 3 seconds</strong>
              <p>Photo, symptom text, and doctor matching in one PWA flow.</p>
            </div>

            <div className="phone-surface__stats">
              <div>
                <span>Visible symptom upload</span>
                <strong>{preview ? "1 image attached" : "Camera ready"}</strong>
              </div>
              <div>
                <span>Latest urgency</span>
                <strong>{result?.urgency?.level || "Pending"}</strong>
              </div>
            </div>
            <div className="phone-surface__pulse" />
          </div>
        </div>
      </section>

      <section className="support-strip">
        {trustHighlights.map((item) => (
          <article key={item.label}>
            <p>{item.label}</p>
            <strong>{item.value}</strong>
          </article>
        ))}
      </section>

      <section className="overview-grid">
        <SharedCard
          eyebrow="Quick Start"
          title="Prompt-led symptom entry"
          copy="Tap a prepared healthcare prompt to start the triage flow faster on mobile."
          action={
            <div className="chip-row">
              {quickPrompts.slice(0, 2).map((prompt) => (
                <button
                  key={prompt.label}
                  type="button"
                  className="chip-button"
                  onClick={() => onPromptSelect(prompt.prompt)}
                >
                  {prompt.label}: {prompt.description}
                </button>
              ))}
            </div>
          }
        />

        <SharedCard
          eyebrow="Personalization"
          title={profileReady ? "Profile details are active" : "Add age, height, and weight"}
          copy={
            profileReady
              ? "Your local profile is included in each triage request to make guidance more tailored."
              : "PulsePath can personalize its responses better when profile details are filled in."
          }
          action={
            <button type="button" className="button button--ghost" onClick={onGoProfile}>
              Open Profile
            </button>
          }
        />

        <SharedCard
          eyebrow="Recent Result"
          title={latestHistory ? latestHistory.result.recommendedDoctor.specialty : "No analysis yet"}
          copy={
            latestHistory
              ? `${latestHistory.result.summary} Saved ${latestHistory.displayTime}.`
              : "Once a user completes triage, the latest summary appears here for quick return."
          }
          action={
            latestHistory ? (
              <button type="button" className="button button--ghost" onClick={onOpenLatest}>
                Open Latest Analysis
              </button>
            ) : null
          }
        />
      </section>
    </>
  );
}
