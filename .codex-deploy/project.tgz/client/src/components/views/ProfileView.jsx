import { SharedCard } from "../SharedCard";
import { buildEmergencyCard } from "../../utils/profile";

export function ProfileView({
  profile,
  profileAvatar,
  profileReady,
  bmi,
  onChangeField,
  onDownloadEmergencyCard,
  onRegenerateIdentity
}) {
  const emergencyCard = buildEmergencyCard(profile);

  return (
    <section className="profile-layout">
      <div className="profile-identity-card">
        <img src={profileAvatar} alt={`${profile.displayName} avatar`} className="profile-identity-card__avatar" />
        <div>
          <p className="eyebrow">Local User Identity</p>
          <h3>{profile.displayName}</h3>
          <p>
            Generated once for this browser and stored locally. No login, no signup, no server-side account.
          </p>
        </div>
        <button type="button" className="button button--ghost" onClick={onRegenerateIdentity}>
          Regenerate Identity
        </button>
      </div>

      <div className="profile-grid profile-grid--details">
        <div className="profile-form">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Editable Details</p>
              <h3>Keep your medical profile ready for offline and triage use</h3>
            </div>
          </div>

          <div className="profile-form__sections">
            <section className="profile-form__section">
              <div className="profile-form__section-copy">
                <p className="eyebrow">Identity</p>
                <h4>Basic details</h4>
                <p>These stay on-device and are reused in future triage requests.</p>
              </div>

              <div className="profile-form__grid">
                <label className="field">
                  <span>Name</span>
                  <input
                    type="text"
                    value={profile.displayName}
                    onChange={(event) => onChangeField("displayName", event.target.value)}
                    placeholder="Your display name"
                  />
                </label>

                <label className="field">
                  <span>Age</span>
                  <input
                    type="number"
                    min="0"
                    value={profile.age}
                    onChange={(event) => onChangeField("age", event.target.value)}
                    placeholder="26"
                  />
                </label>

                <label className="field">
                  <span>Height (cm)</span>
                  <input
                    type="number"
                    min="0"
                    value={profile.heightCm}
                    onChange={(event) => onChangeField("heightCm", event.target.value)}
                    placeholder="172"
                  />
                </label>

                <label className="field">
                  <span>Weight (kg)</span>
                  <input
                    type="number"
                    min="0"
                    value={profile.weightKg}
                    onChange={(event) => onChangeField("weightKg", event.target.value)}
                    placeholder="68"
                  />
                </label>

                <label className="field">
                  <span>Gender</span>
                  <select value={profile.gender} onChange={(event) => onChangeField("gender", event.target.value)}>
                    <option value="">Select</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Non-binary</option>
                    <option>Prefer not to say</option>
                  </select>
                </label>

                <label className="field">
                  <span>Blood group</span>
                  <select value={profile.bloodGroup} onChange={(event) => onChangeField("bloodGroup", event.target.value)}>
                    <option value="">Select</option>
                    <option>A+</option>
                    <option>A-</option>
                    <option>B+</option>
                    <option>B-</option>
                    <option>AB+</option>
                    <option>AB-</option>
                    <option>O+</option>
                    <option>O-</option>
                  </select>
                </label>
              </div>
            </section>

            <section className="profile-form__section">
              <div className="profile-form__section-copy">
                <p className="eyebrow">Medical Context</p>
                <h4>Risks and medicines</h4>
                <p>These fields are used for safety checks, handoff summaries, and the offline emergency card.</p>
              </div>

              <div className="profile-form__grid">
                <label className="field field--full">
                  <span>Allergies</span>
                  <textarea
                    rows={3}
                    value={profile.allergies}
                    onChange={(event) => onChangeField("allergies", event.target.value)}
                    placeholder="Example: penicillin, peanuts, dust"
                  />
                </label>

                <label className="field field--full">
                  <span>Current medicines</span>
                  <textarea
                    rows={3}
                    value={profile.currentMedicines}
                    onChange={(event) => onChangeField("currentMedicines", event.target.value)}
                    placeholder="Example: insulin, amlodipine, warfarin"
                  />
                </label>

                <label className="field field--full">
                  <span>Chronic conditions</span>
                  <textarea
                    rows={3}
                    value={profile.chronicConditions}
                    onChange={(event) => onChangeField("chronicConditions", event.target.value)}
                    placeholder="Example: asthma, diabetes, hypertension"
                  />
                </label>

                <label className="field field--full">
                  <span>Medical notes</span>
                  <textarea
                    rows={4}
                    value={profile.notes}
                    onChange={(event) => onChangeField("notes", event.target.value)}
                    placeholder="Optional: pregnancy, recent surgery, implant, mobility issues, or anything clinicians should know."
                  />
                </label>
              </div>
            </section>

            <section className="profile-form__section">
              <div className="profile-form__section-copy">
                <p className="eyebrow">Emergency Contact</p>
                <h4>Offline card contact details</h4>
                <p>This appears in the emergency card even when the app is used offline.</p>
              </div>

              <div className="profile-form__grid">
                <label className="field">
                  <span>Contact name</span>
                  <input
                    type="text"
                    value={profile.emergencyContactName}
                    onChange={(event) => onChangeField("emergencyContactName", event.target.value)}
                    placeholder="Parent, spouse, sibling"
                  />
                </label>

                <label className="field">
                  <span>Relation</span>
                  <input
                    type="text"
                    value={profile.emergencyContactRelation}
                    onChange={(event) => onChangeField("emergencyContactRelation", event.target.value)}
                    placeholder="Mother"
                  />
                </label>

                <label className="field field--full">
                  <span>Phone number</span>
                  <input
                    type="tel"
                    value={profile.emergencyContactPhone}
                    onChange={(event) => onChangeField("emergencyContactPhone", event.target.value)}
                    placeholder="+91 98765 43210"
                  />
                </label>
              </div>
            </section>
          </div>
        </div>

        <div className="profile-side-stack">
          <section className="emergency-card">
            <div className="panel-heading panel-heading--tight">
              <div>
                <p className="eyebrow">Offline Emergency Card</p>
                <h3>Ready for PWA offline access</h3>
              </div>
              <button type="button" className="button button--ghost" onClick={onDownloadEmergencyCard}>
                Download PDF
              </button>
            </div>

            <div className="emergency-card__grid">
              <div className="emergency-card__line">
                <span>Name</span>
                <strong>{emergencyCard.displayName}</strong>
              </div>
              <div className="emergency-card__line">
                <span>Age / Gender</span>
                <strong>{`${emergencyCard.age} / ${emergencyCard.gender}`}</strong>
              </div>
              <div className="emergency-card__line">
                <span>Blood group</span>
                <strong>{emergencyCard.bloodGroup}</strong>
              </div>
              <div className="emergency-card__line emergency-card__line--full">
                <span>Allergies</span>
                <strong>{emergencyCard.allergies}</strong>
              </div>
              <div className="emergency-card__line emergency-card__line--full">
                <span>Current medicines</span>
                <strong>{emergencyCard.currentMedicines}</strong>
              </div>
              <div className="emergency-card__line emergency-card__line--full">
                <span>Chronic conditions</span>
                <strong>{emergencyCard.chronicConditions}</strong>
              </div>
              <div className="emergency-card__line">
                <span>Emergency contact</span>
                <strong>{emergencyCard.emergencyContactName}</strong>
              </div>
              <div className="emergency-card__line">
                <span>Relation</span>
                <strong>{emergencyCard.emergencyContactRelation}</strong>
              </div>
              <div className="emergency-card__line emergency-card__line--full">
                <span>Phone</span>
                <strong>{emergencyCard.emergencyContactPhone}</strong>
              </div>
              <div className="emergency-card__line emergency-card__line--full">
                <span>Notes</span>
                <strong>{emergencyCard.notes}</strong>
              </div>
            </div>
          </section>

          <div className="profile-grid">
          <SharedCard
            eyebrow="Storage"
            title="Using local storage"
            copy="This is the best fit for your no-login PWA. It survives refreshes, browser restarts, and server restarts on the same device."
          />
          <SharedCard
            eyebrow="Health Snapshot"
            title={bmi ? `BMI ${bmi}` : "Add body details"}
            copy={
              bmi
                ? "Height and weight are stored locally and included in triage requests to improve context."
                : "Age, height, and weight help the app produce more personalized next-step guidance."
            }
            muted={!profileReady}
          />
          <SharedCard
            eyebrow="Status"
            title={profileReady ? "Profile complete" : "Profile partial"}
            copy={
              profileReady
                ? "PulsePath will use this profile automatically in future analyses."
                : "You can leave fields blank, but complete details improve the quality of suggestions."
            }
          />
          <SharedCard
            eyebrow="PWA Behavior"
            title="Data stays in the installed app too"
            copy="When installed as a PWA, this browser storage remains available in the app shell unless the browser site data is cleared."
          />
          </div>
        </div>
      </div>
    </section>
  );
}
