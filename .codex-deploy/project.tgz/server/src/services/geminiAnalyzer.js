import {
  buildPrompt,
  parseImageDataUrl,
  parseStructuredJson,
  TRIAGE_RESPONSE_JSON_SCHEMA,
  withTimeout
} from "./triagePrompt.js";

function buildParts(payload) {
  const prompt = buildPrompt(payload);
  const parts = [];
  const image = parseImageDataUrl(payload.imageDataUrl);

  if (image) {
    parts.push({
      inline_data: {
        mime_type: image.mimeType,
        data: image.data
      }
    });
  }

  parts.push({ text: prompt });

  return parts;
}

function extractTextFromCandidate(candidate) {
  const parts = candidate?.content?.parts || [];

  return parts
    .map((part) => part?.text || "")
    .join("\n")
    .trim();
}

function getModelCandidates(payload) {
  const primaryModel = payload.imageDataUrl
    ? process.env.GEMINI_VISION_MODEL || process.env.GEMINI_MODEL || "gemini-3-flash-preview"
    : process.env.GEMINI_TEXT_MODEL || process.env.GEMINI_MODEL || "gemini-3-flash-preview";

  const fallbackModel = payload.imageDataUrl
    ? process.env.GEMINI_VISION_FALLBACK_MODEL || "gemini-2.5-flash"
    : process.env.GEMINI_TEXT_FALLBACK_MODEL || "gemini-2.5-flash";

  return [primaryModel, fallbackModel].filter((value, index, items) => value && items.indexOf(value) === index);
}

export async function analyzeWithGemini(payload) {
  const requestTimeout = withTimeout(payload.imageDataUrl ? 18000 : 12000);
  const maxOutputTokens = payload.imageDataUrl ? 1800 : 1400;
  let lastError = null;

  try {
    for (const model of getModelCandidates(payload)) {
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
          {
            method: "POST",
            headers: {
              "x-goog-api-key": process.env.GEMINI_API_KEY,
              "Content-Type": "application/json"
            },
            signal: requestTimeout.signal,
            body: JSON.stringify({
              contents: [
                {
                  role: "user",
                  parts: buildParts(payload)
                }
              ],
              generationConfig: {
                temperature: 0.2,
                maxOutputTokens,
                responseMimeType: "application/json",
                responseJsonSchema: TRIAGE_RESPONSE_JSON_SCHEMA
              }
            })
          }
        );

        if (!response.ok) {
          const errorBody = await response.text();
          lastError = new Error(`${model}: Gemini error ${response.status}: ${errorBody}`);
          continue;
        }

        const data = await response.json();
        const candidate = data?.candidates?.[0];
        const content = extractTextFromCandidate(candidate);

        if (!content) {
          lastError = new Error(`${model}: Gemini returned no text content.`);
          continue;
        }

        try {
          return parseStructuredJson(content);
        } catch (error) {
          lastError = new Error(
            `${model}: Gemini returned malformed JSON: ${error.message}\nRAW_RESPONSE:\n${content}`
          );
        }
      } catch (error) {
        lastError = new Error(
          error?.name === "AbortError"
            ? `${model}: Gemini request timed out.`
            : `${model}: ${error.message}${error?.cause?.message ? ` (${error.cause.message})` : ""}`
        );
      }
    }

    throw lastError || new Error("Gemini request failed.");
  } catch (error) {
    throw new Error(error.message);
  } finally {
    requestTimeout.clear();
  }
}
