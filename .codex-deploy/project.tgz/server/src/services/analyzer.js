import { analyzeHeuristically } from "./heuristicAnalyzer.js";
import { analyzeWithGemini } from "./geminiAnalyzer.js";
import { resolveNearbyCare } from "./nearbyCareSearch.js";
import { analyzeWithOpenRouter } from "./openrouterAnalyzer.js";

function preferArray(candidate, fallback) {
  return Array.isArray(candidate) && candidate.length ? candidate : fallback;
}

function isValidUrgency(level) {
  return ["Normal", "Urgent", "Emergency"].includes(level);
}

function mergeWithFallback(aiResult, fallback) {
  const merged = {
    ...fallback,
    ...aiResult,
    symptoms: preferArray(aiResult?.symptoms, fallback.symptoms),
    possibleConditions: preferArray(aiResult?.possibleConditions, fallback.possibleConditions),
    followUpQuestions: preferArray(aiResult?.followUpQuestions, fallback.followUpQuestions),
    imageObservations: preferArray(aiResult?.imageObservations, fallback.imageObservations),
    nextSteps: preferArray(aiResult?.nextSteps, fallback.nextSteps),
    safetyChecks: preferArray(aiResult?.safetyChecks, fallback.safetyChecks),
    recommendedDoctor:
      aiResult?.recommendedDoctor?.specialty && aiResult?.recommendedDoctor?.reason
        ? aiResult.recommendedDoctor
        : fallback.recommendedDoctor,
    urgency: isValidUrgency(aiResult?.urgency?.level) ? aiResult.urgency : fallback.urgency,
    disclaimer: aiResult?.disclaimer || fallback.disclaimer,
    nearbyHospitals: fallback.nearbyHospitals,
    locationContext: fallback.locationContext
  };

  if (!merged.summary || merged.summary.length < 20) {
    merged.summary = fallback.summary;
  }

  return merged;
}

export async function analyzeSymptoms(payload) {
  const heuristicFallback = analyzeHeuristically(payload);
  const nearbyCarePromise = resolveNearbyCare({
    location: payload?.location,
    urgencyLevel: heuristicFallback.urgency.level,
    recommendedSpecialty: heuristicFallback.recommendedDoctor.specialty
  });
  let lastProviderError = "";

  if (process.env.GEMINI_API_KEY) {
    try {
      const aiResult = await analyzeWithGemini({
        ...payload,
        baseline: heuristicFallback
      });
      const nearbyCare = await nearbyCarePromise;
      const fallback = {
        ...heuristicFallback,
        nearbyHospitals: nearbyCare.nearbyHospitals.length
          ? nearbyCare.nearbyHospitals
          : heuristicFallback.nearbyHospitals,
        locationContext: nearbyCare.locationContext
      };

      return {
        ...mergeWithFallback(aiResult, fallback),
        source: "gemini"
      };
    } catch (error) {
      lastProviderError = `gemini: ${error.message}`;
      console.error("Gemini analysis failed, trying secondary providers.", error.message);
    }
  }

  if (process.env.OPENROUTER_API_KEY) {
    try {
      const aiResult = await analyzeWithOpenRouter({
        ...payload,
        baseline: heuristicFallback
      });
      const nearbyCare = await nearbyCarePromise;
      const fallback = {
        ...heuristicFallback,
        nearbyHospitals: nearbyCare.nearbyHospitals.length
          ? nearbyCare.nearbyHospitals
          : heuristicFallback.nearbyHospitals,
        locationContext: nearbyCare.locationContext
      };

      return {
        ...mergeWithFallback(aiResult, fallback),
        source: "openrouter"
      };
    } catch (error) {
      lastProviderError = `${lastProviderError ? `${lastProviderError} | ` : ""}openrouter: ${error.message}`;
      console.error("OpenRouter analysis failed, falling back to heuristics.", error.message);
    }
  }

  const nearbyCare = await nearbyCarePromise;
  const fallback = {
    ...heuristicFallback,
    nearbyHospitals: nearbyCare.nearbyHospitals.length
      ? nearbyCare.nearbyHospitals
      : heuristicFallback.nearbyHospitals,
    locationContext: nearbyCare.locationContext
  };

  return lastProviderError
    ? {
        ...fallback,
        aiDebug: lastProviderError
      }
    : fallback;
}
