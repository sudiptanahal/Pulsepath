import cors from "cors";
import dotenv from "dotenv";
import express from "express";
import { fileURLToPath } from "url";
import { analyzeSymptoms } from "./services/analyzer.js";
import { analyzeHeuristically } from "./services/heuristicAnalyzer.js";
import { resolveNearbyCare } from "./services/nearbyCareSearch.js";

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 4000);
const currentFilePath = fileURLToPath(import.meta.url);

app.use(
  cors({
    origin: true
  })
);
app.use(express.json({ limit: "12mb" }));

app.get("/api/health", (_request, response) => {
  const aiProvider = process.env.GEMINI_API_KEY
    ? "gemini"
    : process.env.OPENROUTER_API_KEY
      ? "openrouter"
      : "heuristic-fallback";

  response.json({
    ok: true,
    service: "pulsepath-api",
    aiConfigured: aiProvider !== "heuristic-fallback",
    aiProvider
  });
});

app.post("/api/analyze", async (request, response) => {
  const { message = "", imageDataUrl = "" } = request.body || {};

  if (!message.trim() && !imageDataUrl) {
    response.status(400).json({
      error: "A symptom description or symptom image is required."
    });
    return;
  }

  try {
    const result = await analyzeSymptoms(request.body);
    response.json(result);
  } catch (error) {
    console.error("Analyze endpoint failed.", error.message);
    response.status(500).json({
      error: "PulsePath could not analyze the symptoms right now. Please try again."
    });
  }
});

app.get("/api/hospitals", async (request, response) => {
  const location =
    request.query.lat && request.query.lng
      ? {
          label: request.query.location || "Current location",
          city: request.query.location || "Current location",
          coords: {
            lat: Number(request.query.lat),
            lng: Number(request.query.lng)
          }
        }
      : request.query.location || "Kolkata";
  const fallback = analyzeHeuristically({
    location,
    message: request.query.message || ""
  });

  try {
    const nearbyCare = await resolveNearbyCare({
      location,
      urgencyLevel: fallback.urgency.level,
      recommendedSpecialty: fallback.recommendedDoctor.specialty
    });

    response.json(
      nearbyCare.nearbyHospitals.length ? nearbyCare.nearbyHospitals : fallback.nearbyHospitals
    );
  } catch {
    response.json(fallback.nearbyHospitals);
  }
});

export default app;

if (process.argv[1] === currentFilePath) {
  app.listen(port, () => {
    console.log(`PulsePath API listening on http://localhost:${port}`);
  });
}
